package com.example.projectrserver;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import net.daum.mf.map.api.MapPOIItem;
import net.daum.mf.map.api.MapPoint;
import net.daum.mf.map.api.MapView;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.protocol.HTTP;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class MainActivity extends Activity implements MapView.MapViewEventListener, MapView.POIItemEventListener, MapView.CurrentLocationEventListener
{
    /* int */
    private int GamCount = 0;
    private int GamCountTotal = 0;

    /* MapView */
    private MapView mapView = null;

    /* Context */
    private Context mContext = MainActivity.this;

    /* String */
    private String mDataString = null;

    /* EditText */
    private EditText mEditText[] = {null, null, null};

    private void RequestGPS() /* GPS Control Method */
    {
        // Acquire a reference to the system Location Manager
        LocationManager locationManager = (LocationManager) this.getSystemService(Context.LOCATION_SERVICE);

        // Define a listener that responds to location updates
        LocationListener locationListener = new LocationListener()
        {
            /* GPS의 좌표가 바뀔 경우 호출 되는 함수 */
            public void onLocationChanged(Location location)
            {
                // Called when a new location is found by the network location provider.
                double mLatitude = location.getLatitude(); /* 위도 */
                double mLongitude= location.getLongitude(); /* 경도 */

                mapView.setMapCenterPoint(MapPoint.mapPointWithGeoCoord(mLatitude, mLongitude), true); /* 지도 중심점 변경 */
            }

            public void onStatusChanged(String provider, int status, Bundle extras) {}
            public void onProviderEnabled(String provider) {}
            public void onProviderDisabled(String provider) {}
        };

        // Register the listener with the Location Manager to receive location updates
        locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 0, 0, locationListener);
    }

    /* 사용자 정의 함수 */
    private void CreateMarker(String item, String mapX, String mapY)
    {
        int i = Integer.valueOf(item).intValue();
        double X = Double.valueOf(mapX).doubleValue();
        double Y = Double.valueOf(mapY).doubleValue();

        MapPOIItem mMapMarker = new MapPOIItem(); /* Maker 객체 생성 */
        mMapMarker.setItemName("Gam" + item); /* Maker Name Set */
        mMapMarker.setTag(i); /* Maker Tag Set */
        mMapMarker.setMapPoint(MapPoint.mapPointWithGeoCoord(X, Y)); /* Map Marker Create */
        mMapMarker.setMarkerType(MapPOIItem.MarkerType.BluePin); /* Maker Type Set */

        mapView.addPOIItem(mMapMarker); /* Map Maker Add */
        new PHPNetwork().execute("J", mapX, mapY, item, mEditText[1].getText().toString(), mDataString);
    }

    private class PHPNetwork extends AsyncTask<String, Void, Void>
    {
        private ProgressDialog mProgressDialog = new ProgressDialog(mContext);

        @Override /* 프로세스가 실행되기 전에 실행 되는 부분 - 초기 설정 부분 */
        protected void onPreExecute()
        {
			/* ProgressDialog 설정 구문 */
            mProgressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER); /* 원형 프로그래스 다이얼 로그 스타일로 설정 */
            mProgressDialog.setMessage("잠시만 기다려 주세요.");
            mProgressDialog.show();
            super.onPreExecute();
        }

        @Override
        protected Void doInBackground(String... params)
        {
            String mString = "http://Marihome.iptime.org/projectr/";
            HttpClient mClient = new DefaultHttpClient();
            HttpPost mPost = null;
            List<NameValuePair> mParam = new ArrayList<NameValuePair>(10);

            switch(params[0])
            {
                case ("J") :
                {
                    mPost = new HttpPost(mString + "zam_db_insert.php");

                    mParam.add(new BasicNameValuePair("mapx", params[1])); /* 위도 */
                    mParam.add(new BasicNameValuePair("mapy", params[2])); /* 경도 */
                    mParam.add(new BasicNameValuePair("tag", params[3])); /* 태그 */
                    mParam.add(new BasicNameValuePair("port", params[4])); /* 포트 */
                    mParam.add(new BasicNameValuePair("date", params[5])); /* 날짜 */
                    break;
                }
                case ("S") :
                {
                    mPost = new HttpPost(mString + "server_db_insert.php");

                    mParam.add(new BasicNameValuePair("time", params[1])); /* 시간 */
                    mParam.add(new BasicNameValuePair("gamcount", params[2])); /* 보석의 수 */
                    mParam.add(new BasicNameValuePair("data", params[3])); /* 날짜 */
                    mParam.add(new BasicNameValuePair("port", params[4])); /* 포트 */
                    break;
                }
            }

            try
            {
                UrlEncodedFormEntity mUrlEncodedFormEntity = null;
                mUrlEncodedFormEntity = new UrlEncodedFormEntity(mParam, HTTP.UTF_8);
                mPost.setEntity(mUrlEncodedFormEntity);

                HttpResponse mHttpResponse = mClient.execute(mPost);
                HttpEntity mHttpEntity = mHttpResponse.getEntity();
            }
            catch (UnsupportedEncodingException e) { e.printStackTrace(); }
            catch (ClientProtocolException e) { e.printStackTrace(); }
            catch (IOException e) { e.printStackTrace(); }

            return null;
        }

        @Override
        protected void onPostExecute(Void result)
        {
            mProgressDialog.dismiss(); /* mProgressDialog 종료 부분 */
            super.onPostExecute(result);
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        /* TIME Set */
        Calendar mCalendar = Calendar.getInstance();
        SimpleDateFormat mSimpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
        mDataString = mSimpleDateFormat.format(mCalendar.getTime());

        /* EditText */
        mEditText[0] = (EditText)findViewById(R.id.GamEdit);
        mEditText[1] = (EditText)findViewById(R.id.PortEdit);
        mEditText[2] = (EditText)findViewById(R.id.TimeEdit);

        mEditText[0].setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                if (keyCode == event.KEYCODE_ENTER) {
                    GamCountTotal = Integer.parseInt(mEditText[0].getText().toString());
                    return true;
                }
                return false;
            }
        });

        /* Daum API */
        mapView = new MapView(mContext);
        mapView.setDaumMapApiKey("897380370b9ba91ed02f5bf2a0b9c0b2"); /* API KEY 설정 */
        ViewGroup mapViewContainer = (ViewGroup)findViewById(R.id.DaumMap); /* 다음 레이아웃 객체 생성 */
        mapViewContainer.addView(mapView); /* MapContainer 생성 */

        RequestGPS(); /* GPS Request Method Call */

        /* Map Event */
        mapView.setMapViewEventListener(this); /* MapView Event */
        mapView.setPOIItemEventListener(this); /* MapView POIITEM */

        /* Button */
        Button mButton = (Button)findViewById(R.id.TransferBut);
        mButton.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                new PHPNetwork().execute("S", mEditText[2].getText().toString(), mEditText[0].getText().toString(), mDataString, mEditText[1].getText().toString());
                Toast.makeText(mContext, "정상적으로 저장이 완료되었습니다.", Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public void onCurrentLocationUpdate(MapView mapView, MapPoint mapPoint, float v) {

    }

    @Override
    public void onCurrentLocationDeviceHeadingUpdate(MapView mapView, float v) {

    }

    @Override
    public void onCurrentLocationUpdateFailed(MapView mapView) {

    }

    @Override
    public void onCurrentLocationUpdateCancelled(MapView mapView) {

    }

    @Override
    public void onMapViewInitialized(MapView mapView) {

    }

    @Override
    public void onMapViewCenterPointMoved(MapView mapView, MapPoint mapPoint) {

    }

    @Override
    public void onMapViewZoomLevelChanged(MapView mapView, int i) {

    }

    @Override
    public void onMapViewSingleTapped(MapView mapView, MapPoint mapPoint) {

    }

    @Override
    public void onMapViewDoubleTapped(MapView mapView, MapPoint mapPoint) {

    }

    /* 길게 누를 경우 */
    @Override
    public void onMapViewLongPressed(MapView mapView, MapPoint mapPoint)
    {
        if(GamCount < GamCountTotal)
        { CreateMarker(Integer.toString(++GamCount), Double.toString(mapPoint.getMapPointGeoCoord().latitude), Double.toString(mapPoint.getMapPointGeoCoord().longitude)); }
        else { Toast.makeText(mContext, "보석의 수가 초과하였습니다.", Toast.LENGTH_SHORT).show(); }
    }

    @Override
    public void onMapViewDragStarted(MapView mapView, MapPoint mapPoint) {

    }

    @Override
    public void onMapViewDragEnded(MapView mapView, MapPoint mapPoint) {

    }

    @Override
    public void onMapViewMoveFinished(MapView mapView, MapPoint mapPoint) {

    }

    @Override
    public void onPOIItemSelected(MapView mapView, MapPOIItem mapPOIItem) {

    }

    @Override
    public void onCalloutBalloonOfPOIItemTouched(MapView mapView, MapPOIItem mapPOIItem) {

    }

    @Override
    public void onCalloutBalloonOfPOIItemTouched(MapView mapView, MapPOIItem mapPOIItem, MapPOIItem.CalloutBalloonButtonType calloutBalloonButtonType) {

    }

    @Override
    public void onDraggablePOIItemMoved(MapView mapView, MapPOIItem mapPOIItem, MapPoint mapPoint) {

    }
}
